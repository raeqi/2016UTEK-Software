/* Path Finding module */

/* Chenyu Wang 2016/01/16 */

/*when executed, takes the number of entries of pathfinding requests, load up the map stored in map.txt that is fetched from the shapefile. and output
the shortest path information to the out.txt file that can be used by the webapp*/

/*
    map.txt format:

    map.txt is a file fetched from shapfile by the python fetching module(since the shapefile library in c++ is confusing)

    everyline is a single node of the graph, node consists of node id(GEO_ID of the intersection), edge id(the end point of the edge), edge length(or cost)

    every line should be in the form of: nodeid edgeid edgelength edgeid edgelength edgeid.... (depends on how many edges you have)
*/

/*
    output format:

    first line will be the path length of the request
    second line will be the number of nodes in the path
    from third line it will be an array of nodeids to specify the path

    all output will be saved to the output.txt file for webapp to use

    the output of multiple requests will be accumulated into one file
*/

#include <map>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

class edge{         //decribed an path from one node to another node
private:
    unsigned id;        //the destination id
    double cost;        //the lenght of the path
public:
    edge(unsigned Id, double Cost){id=Id; cost=Cost;}
    ~edge(){};
    unsigned getid(){return id;}
    double getcost(){return cost;}
    void print(){
        cout << id << " " << cost << endl;
    }
};

class node{
private:
    unsigned id;
    vector<edge> edges;
    double dist;
    char inU;       //if the node is U(the node is in U or not)
    unsigned next;     //the next node in the shortest path
public:
    node(){id=-1;}
    node(unsigned Id, vector<edge> Edges){id=Id; edges=Edges;dist=-1; next=0;}   //dist=-1 means infinity in unsigned
    ~node(){}
    unsigned getid(){return id;}
    vector<edge> getedges(){return edges;}
    double getdist(){return dist;}
    void setdist(double newdist){dist=newdist;}
    char getinU(){return inU;}
    void setinU(char newinU){inU=newinU;}
    void setnext(unsigned newnext){next=newnext;}
    unsigned getnext(){return next;}
};


double findpath(map<unsigned,node> &graph,unsigned startid,unsigned endid){           //find the shortest path by setting the prev in the map to proper nodes. return the length of the path
    //initialization
    const unsigned mapsize=graph.size();
    unsigned counter=mapsize;
    unsigned headid=startid;        //the current branching head's id
    for(auto &n:graph){
        n.second.setinU(1);     //all of them are unprocessed in the beginning
        n.second.setdist(1e50);   //infinity
    }
    graph[headid].setinU(0);
    graph[headid].setdist(0);      //0 distance from itself
    counter--;

    unsigned nextid=headid;
    while(counter!=0){      //counter=0 means everything is in the processed set(inU=0)
        node &head=graph[nextid];
        for(auto &edge:head.getedges()){            //update the shortest path to the nodes near head
            double newdist=head.getdist()+edge.getcost();
            node &target=graph[edge.getid()];
            if(newdist<target.getdist()){
                target.setdist(newdist);
            }
        }
        double mindist=1e50;
        unsigned mindistid=-1;      //the id of the min distance value node around head
        for(auto &edge:head.getedges()){ //checks and finds the node that have the smallest dist and not yet in set S -- change it to the head on the next iteration and make it into S
            node &target=graph[edge.getid()];
            if((target.getdist()<mindist)&&(target.getinU())){
                mindist=target.getdist();
                mindistid=target.getid();
            }
        }
        node &target=graph[mindistid];
        head.setnext(mindistid);
        target.setinU(0);
        nextid=mindistid;
        counter--;
    }

    return graph[endid].getdist();
}

void parsemap(map<unsigned, node> &graph){         //parse all the information and put them inside the graph
    ifstream infile("map.txt");
    string line;
    while(getline(infile,line)){
        if(infile.eof()){           //reached the end of file, stop parsing
            return;
        }
        //building a node and add it to the graph
        unsigned id, edgeid;
        double edgecost;
        vector<edge> edges;
        stringstream linestream;
        linestream.str(line);
        linestream >> id;
        while(!linestream.eof()){
            linestream >> edgeid;
            linestream >> edgecost;
            edge temp(edgeid,edgecost);
            edges.push_back(temp);
        }
        node temp(id,edges);
        graph[id]=temp;
    }
}

int main(){
    map<unsigned,node> graph;
    parsemap(graph);            //graph loading

    unsigned num;   //scan in the number of tests
    cin  >> num;
    unsigned startid, endid;
    ofstream fout("output.txt", ofstream::out);
    for(int i=0;i<num;i++){
        cin >> startid >> endid;            //build the path vector
        fout << findpath(graph,startid,endid) << endl;      //give the path length first
        vector<unsigned> idlist;
        unsigned headid=startid;
        while(headid!=endid){
            idlist.push_back(headid);
            headid=graph[headid].getnext();
        }
        idlist.push_back(endid);

        fout << idlist.size() << endl;          //give the number of nodes on the path
        for(int i=0;i<idlist.size();i++){       //give all the points in the path
            fout << idlist[i] << endl;
        }
    }

    return 0;
}

