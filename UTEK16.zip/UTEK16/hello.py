directions = []

from flask import Flask, render_template, request, redirect
app = Flask(__name__)

@app.route('/')
def show_index():
    title = "NaviMaps"
    return render_template('index.html', title=title)

@app.route('/directions/', methods = ['POST'])
def show_dir():
    addr1 = request.form['addr1']
    addr2 = request.form['addr2']
    directions.append("follow st george street and keep going south")
    directions.append("stop when you reach lake Ontario.")
    directions.append("jump right into the lake and drown yourself")
    directions.append("i can't python ._. ") 
    return redirect('directions.html', addr1=addr1, addr2=addr2, directions=directions)

@app.route('/hello/')
def say_hi():
    return "this page is freaking useless. come bite me."

if __name__ == "__main__":
    app.run()

    