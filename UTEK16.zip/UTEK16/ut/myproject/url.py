__author__ = 'gengxin'

from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def hello_world():
    author = "Me"
    name = "You"
    return render_template('16.html', author=author, name=name)

@app.route('/hello')
def hello():
    return 'hello world'


if __name__ == "__main__":
    app.run()

