""" 
Python file for parsing shapefile
To get the file fed into C++ shortest path algorithm
feed shp dbf files into the function
make_graph(road_shp, road_dbf, intersection_shp, intersection_dbf):
"""
import shapefile
from math import cos, asin, sqrt


def distance(lat1, lon1, lat2, lon2):
    """ calculate distance between two points """
    p = 0.017453292519943295
    a = 0.5 - cos((lat2 - lat1) * p)/2 + cos(lat1 * p) * cos(lat2 * p) * (1 - cos((lon2 - lon1) * p)) / 2
    return 12742 * asin(sqrt(a))

def split_road(string):
    """ split the string into a list 
        eg. "ab / cd / ef" ---> ["ab","cd","ef"] """
    return [i for i in string.split(" / ")] 

def find_street_nodes(street_name):
    """ split the string into a list 
        eg. "ab / cd / ef" ---> ["ab","cd","ef"] """
    nodes = []
    for i in street_data:
        for j in i[1]:  
            if j == street_name:
                nodes.append(i[0])
    return nodes



def make_graph(road_shp, road_dbf, intersection_shp, intersection_dbf):
    global street_data 
    street_dbf = open(road_dbf,"rb")
    street_shp = open(road_shp,"rb")
    node_dbf = open(intersection_dbf,"rb")
    node_shp = open(intersection_shp,"rb")
    street_object = shapefile.Reader(shp = street_shp, dbf = street_dbf)
    node_object = shapefile.Reader(shp = node_shp, dbf = node_dbf)


    ### get a list of
    node_coordinate = [i.points[0] for i in node_object.shapes()]


    my_node = node_object.records()
    # intersection index
    intersection_index = [i[0] for i in my_node]
    # streets per intersection  "streetA / streetB" format
    street_rawdata = [i[2] for i in my_node]
    # intersection coordinate
    intersection_coor = [ [i[16],i[15]] for i in my_node]

    # merge intersection index, corresponding streets and intersection coordinate
    street_impaired_data = [list(i) for i in list(zip(intersection_index, street_rawdata))]



    # get rid of useless data 
    street_processing_data = [i for i in street_impaired_data if not(type(i[1]) is bytes)]
    # processing road (split string into list of road)
    # for each node   enumerate a list of roads connecting to it
    # e.g  [[NodeID, [roadA, roadB .. ]] ....]
    street_data = [[i[0],split_road(i[1])] for i in street_processing_data]

    # merge coordinates
    # e.g [ [NodeID, [RoadA,RoadB,...], [X, Y]] ... ]
    for ele_a, ele_b in zip(street_data, intersection_coor):
        ele_a.append(ele_b)

    my_street = street_object.records()
    ### get a list of street names
    street_name = [i[2] for i in my_street]

    street_nodes = list(map(find_street_nodes, street_name))
    #
    # e.g [[roadA, [NodeID_A, NodeID_B ...]] ...]
    street_to_nodes = [list(i) for i in list(zip(street_name, street_nodes))]


    """target output file format:
    NodeID_1 Node_1 Dis_1 Node_2 Dis_2 Node_3 Dis_3 Node_4 Dis_4
    NodeID_2 Node_1 Dis_1 Node_2 Dis_2 Node_3 Dis_3 Node_4 Dis_4
    NodeID_2 Node_1 Dis_1 Node_2 Dis_2 Node_3 Dis_3 Node_4 Dis_4

    for street_data  = [ [NodeID, [RoadA,RoadB,...], [X, Y]] ... ]
    replace RoadA, RoadB according to street_to_nodes

    streeet_data ->  [ [NodeID, [ [NodeIDs_A], [NodeIDs_B] ..], [ X, Y ]] ...]
   
    replace NodeIDs_A, NodeIDs_B with each street_data's [X,Y]
    and calculate the distance in terms of the original [X, Y]
    for the target output file.
    """

def node_type(lst, index):
	types = []
	for i in lst:
		if not(i[index] in types):
			types.append(i[index])
	return types

